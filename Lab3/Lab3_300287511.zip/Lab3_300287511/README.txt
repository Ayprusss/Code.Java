Student Name: Anthony Le
Student Number: 300287511
Course code: ITI 1121
Lab section: C-02

this archive contains 3 files for the lab 3, those files being the README.txt, Utils.java, and Rational.java.